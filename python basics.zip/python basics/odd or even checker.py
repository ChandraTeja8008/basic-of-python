def parse_int(value: str) -> int:
    """Convert user input to an integer with error handling."""
    try:
        # Allow users to type numbers like "10" only.
        return int(value)
    except ValueError:
        raise ValueError("Invalid input. Please enter an integer.")


def main() -> None:
    print("--- Odd or Even Checker ---")

    n_raw = input("Enter an integer: ").strip()

    try:
        n = parse_int(n_raw)
        if n % 2 == 0:
            print(f"{n} is Even")
        else:
            print(f"{n} is Odd")
    except ValueError as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main()

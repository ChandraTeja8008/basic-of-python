def parse_year(value: str) -> int:
    """Parse user input to an integer year with validation."""
    try:
        year = int(value)
    except ValueError:
        raise ValueError("Invalid input. Please enter a valid year (integer).")

    # Basic sanity check (optional)
    if year <= 0:
        raise ValueError("Invalid input. Year must be a positive integer.")
    return year


def is_leap_year(year: int) -> bool:
    """Return True if year is a leap year, else False."""
    if year % 400 == 0:
        return True
    if year % 100 == 0:
        return False
    return year % 4 == 0


def main() -> None:
    print("--- Leap Year Check ---")

    year_raw = input("Enter a year: ").strip()

    try:
        year = parse_year(year_raw)
        if is_leap_year(year):
            print(f"{year} is a Leap Year")
        else:
            print(f"{year} is Not a Leap Year")
    except ValueError as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main()

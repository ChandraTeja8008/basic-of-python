def main() -> None:
    print("--- String Reverse ---")

    s = input("Enter a string: ")

    reversed_s = s[::-1]
    print("Reversed string:")
    print(reversed_s)


if __name__ == "__main__":
    main()

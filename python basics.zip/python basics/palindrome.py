def normalize(s: str) -> str:
    """Normalize string by removing spaces and converting to lowercase."""
    return "".join(ch for ch in s.lower() if not ch.isspace())


def main() -> None:
    print("--- Palindrome Check ---")

    s = input("Enter a string: ")
    normalized = normalize(s)

    if normalized == normalized[::-1]:
        print("It is a Palindrome")
    else:
        print("It is Not a Palindrome")


if __name__ == "__main__":
    main()


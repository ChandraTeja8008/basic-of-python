def parse_float(value: str) -> float:
    """Convert user input to float with basic error handling."""
    try:
        return float(value)
    except ValueError:
        raise ValueError("Invalid input. Please enter a number.")


def main() -> None:
    print("--- Sum of Two Numbers ---")

    # Read inputs (handles cases where the user provides fewer inputs)
    try:
        a_raw = input("Enter first number: ").strip()
        b_raw = input("Enter second number: ").strip()
    except EOFError:
        print("Error: Not enough input provided.")
        return


    try:
        a = parse_float(a_raw)
        b = parse_float(b_raw)
        total = a + b
        # If both inputs are whole numbers, print as int-like result
        if a.is_integer() and b.is_integer():
            print(f"Sum: {int(total)}")
        else:
            print(f"Sum: {total}")
    except ValueError as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main()


def parse_int(value: str) -> int:
    """Parse user input into an integer with error handling."""
    try:
        return int(value)
    except ValueError:
        raise ValueError("Invalid input. Please enter an integer.")


def is_armstrong(n: int) -> bool:
    """Check whether n is an Armstrong number."""
    if n < 0:
        return False

    digits = list(map(int, str(n)))
    k = len(digits)

    total = 0
    for d in digits:
        total += d ** k

    return total == n


def main() -> None:
    print("--- Armstrong Number Check ---")

    n_raw = input("Enter an integer: ").strip()

    try:
        n = parse_int(n_raw)
        if is_armstrong(n):
            print(f"{n} is an Armstrong Number")
        else:
            print(f"{n} is Not an Armstrong Number")
    except ValueError as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main()


Python 3.13.13 (tags/v3.13.13:01104ce, Apr  7 2026, 19:25:48) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
= RESTART: C:/Users/hariv/AppData/Local/Programs/Python/Python313/odd or even checker.py
--- Odd or Even Checker ---
Enter an integer: 45
45 is Odd
>>> 
= RESTART: C:/Users/hariv/AppData/Local/Programs/Python/Python313/factorial.py =
--- Factorial Calculation ---
Enter a non-negative integer: 65
Factorial of 65 is 8247650592082470666723170306785496252186258551345437492922123134388955774976000000000000000
>>> 
== RESTART: C:/Users/hariv/AppData/Local/Programs/Python/Python313/fibnocci.py =
>>> 46
46
>>> 56
56
>>> 
= RESTART: C:/Users/hariv/AppData/Local/Programs/Python/Python313/reverse a string.py
--- String Reverse ---
Enter a string: hari
Reversed string:
irah
>>> 
= RESTART: C:/Users/hariv/AppData/Local/Programs/Python/Python313/palindrome.py
--- Palindrome Check ---
Enter a string: 445
It is Not a Palindrome
>>> 
= RESTART: C:/Users/hariv/AppData/Local/Programs/Python/Python313/leap year.py =
--- Leap Year Check ---
Enter a year: 2024
2024 is a Leap Year
>>> 
= RESTART: C:/Users/hariv/AppData/Local/Programs/Python/Python313/Armstrong number.py
--- Armstrong Number Check ---
Enter an integer: 456
456 is Not an Armstrong Number

= RESTART: C:/Users/hariv/AppData/Local/Programs/Python/Python313/sum of two numbers .py
--- Sum of Two Numbers ---
Enter first number: 24
Enter second number: 56
Sum: 80

def parse_non_negative_int(value: str) -> int:
    """Parse user input into a non-negative integer."""
    try:
        n = int(value)
    except ValueError:
        raise ValueError("Invalid input. Please enter a non-negative integer.")

    if n < 0:
        raise ValueError("Invalid input. Number must be non-negative.")
    return n


def generate_fibonacci(n: int) -> list[int]:
    """Generate the first n Fibonacci numbers."""
    sequence = []

    # Handle edge cases first
    if n == 0:
        return sequence
    if n == 1:
        return [0]

    a, b = 0, 1
    for _ in range(n):
        sequence.append(a)
        a, b = b, a + b

    return sequence


def main() -> None:
    print("--- Fibonacci Sequence ---")

    n_raw = input("Enter how many terms (n): ").strip()

    try:
        n = parse_non_negative_int(n_raw)
        seq = generate_fibonacci(n)
        print(f"First {n} Fibonacci numbers:")
        print(*seq)
    except ValueError as e:
        print(f"Error: {e}")

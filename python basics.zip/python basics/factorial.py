def parse_non_negative_int(value: str) -> int:
    """Parse user input into a non-negative integer."""
    try:
        n = int(value)
    except ValueError:
        raise ValueError("Invalid input. Please enter a non-negative integer.")

    if n < 0:
        raise ValueError("Invalid input. Number must be non-negative.")
    return n


def factorial(n: int) -> int:
    """Compute factorial of n using a loop."""
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result


def main() -> None:
    print("--- Factorial Calculation ---")

    n_raw = input("Enter a non-negative integer: ").strip()

    try:
        n = parse_non_negative_int(n_raw)
        print(f"Factorial of {n} is {factorial(n)}")
    except ValueError as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main()
